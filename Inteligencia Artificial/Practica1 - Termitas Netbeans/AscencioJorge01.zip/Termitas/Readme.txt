Ascencio Espíndola Jorge Eduardo
309043511
Práctica 01
La evolución 3 no la hice tan aleatorio el escoger la casilla libre.
