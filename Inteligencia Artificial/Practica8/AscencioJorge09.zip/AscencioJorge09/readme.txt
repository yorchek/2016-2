309043511
Ascencio Espíndola Jorge Eduardo

Ejecución

ejecutar en terminal con:

python aGeneticos.py